---
name: Other issue
about: Report some other issue or request a feature
labels: ''
assignees: ''
---
**NOTE: Npcap issues have moved to [the Npcap repository](https://github.com/nmap/npcap/issues/)**

**NOTE: Ncrack issues have moved to [the Ncrack repository](https://github.com/nmap/ncrack/issues/)**

**Describe the current behavior**
A clear and concise description of what the bug or current behavior is.

**Expected behavior**
Describe what you would like to happen instead.

