---
name: Bug report
about: Create an actionable bug report
title: ''
labels: ''
assignees: ''

---

Please read https://karma-runner.github.io/4.0/intro/troubleshooting.html first
