exports.formatError = function formatErrorProperty (msg) {
  return msg
}
