// a valid --format-error file
module.exports = function formatErrorRoot (msg) {
  return msg
}
