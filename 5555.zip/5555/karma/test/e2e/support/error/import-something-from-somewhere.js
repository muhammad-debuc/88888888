import { something } from './somewhere.js'
console.log(something)
