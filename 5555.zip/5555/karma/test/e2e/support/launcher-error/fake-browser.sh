#!/bin/bash

echo "Missing fake dependency" 1>&2
exit 1
