
console.log('foo')
console.debug('bar')
console.info('baz')
console.warn('foobar')
console.error('barbaz')
