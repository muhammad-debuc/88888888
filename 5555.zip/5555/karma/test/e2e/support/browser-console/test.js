describe('Truism', function () {
  it('should pass', function () {
    expect(true).toBe(true)
  })
})
