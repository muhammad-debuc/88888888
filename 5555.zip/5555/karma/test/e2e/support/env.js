const { setDefaultTimeout } = require('cucumber')

setDefaultTimeout(60 * 1000)
