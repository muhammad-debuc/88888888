'/base/headers/foo.js source'
