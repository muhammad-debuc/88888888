// Some code under test
export function plus (a, b) {
  return a + b
}
