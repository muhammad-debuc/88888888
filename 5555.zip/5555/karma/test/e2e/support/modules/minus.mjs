// Some code under test
export function minus (a, b) {
  return a - b
}
