import { plus } from '../plus.js'

describe('plus', function () {
  it('should pass', function () {
    expect(true).to.be.true
  })

  it('should work', function () {
    expect(plus(1, 2)).to.equal(3)
  })
})
