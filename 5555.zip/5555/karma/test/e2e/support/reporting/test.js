describe('Reporting order', () => {
  it('sync test', () => {
    // pass
  })

  it('async test', (done) => {
    setTimeout(done, 200)
  })
})
