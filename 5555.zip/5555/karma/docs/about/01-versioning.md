Karma uses [Semantic Versioning].

It is recommended that you add Karma by running:

```bash
$ yarn add --dev karma
```

or: 

```bash
$ npm --save-dev install karma
```

[Semantic Versioning]: https://semver.org/
